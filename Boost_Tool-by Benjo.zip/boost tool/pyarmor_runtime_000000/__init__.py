# Pyarmor 8.5.2 (trial), 000000, 2024-03-29T19:49:12.098493
from .pyarmor_runtime import __pyarmor__
