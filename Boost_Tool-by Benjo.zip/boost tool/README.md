
Remember This Boost Tool ONLY allows you to boost servers if you have nitro tokens!

To add Tokens go to Input and there u find 2 .txt files. 1m_tokens.txt = 1 Month Tokens, 3m_tokens.txt = 3 Month Tokens

Download Python here: [DOWNLOAD](https://www.python.org/downloads/) 

(Python v3.9 or higher is recommended)

If anymore help is needed, add me on discord: @r_benjo (727212604824617020)



### Requirements:
- [x] - **Windows 10 / 11**
- [x] - **Python** [DOWNLOAD](https://www.python.org/ftp/python/3.10.5/python-3.10.5-amd64.exe)
- [x] - **key** 
- [ ] - **Your own proxies (I recommend paid proxies but free works)**
