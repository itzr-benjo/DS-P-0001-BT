# Pyarmor 8.5.2 (trial), 000000, 2024-03-31T00:49:12.508839
from .pyarmor_runtime import __pyarmor__
